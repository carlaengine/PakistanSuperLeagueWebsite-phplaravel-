<div class="col-md-3 text-white">
    <h2 class="text-left">PSL 6</h2><hr>
    <p class="text-left">&copy; 2023<a href="wwww.google.com">google</a>, all rights reserved  </p> 
    <img src="images\HBLPSLV_2020.jpeg" width="300" height="200">
</div>

<div class="col-md-3 text-center">
    <h4 class="text-white">Quick Menu</h4><hr>
    <ul>
       <li><a href="#">Privacy Policy</a></li>
       <li><a href="#">terms & conditions</a></li>
       <li><a href="#">Disclaimer</a></li>
       <li><a href="#">Contact Us</a></li>


    </ul>
</div>
<div class="col-md-3 text-white ">
    <h4 class="text-center text-white">No.of Visitors</h4><hr>
    <p class="text-center text-white">5555</p>
    <h4 class=" text-white">Design and developed by</h4><hr>
    <a class="btn btn-danger btn-lg btn-block " href="">Bzsoftware</a>
   
</div>
<div class="col-md-3 text-white text-center ">
    <h4 class="text-center text-white">Address</h4><hr>
    <address>
         Bzsoftware<br>
         near Gushan-e-iqbal<br>
         karachi<br>
         Dist:nanded<br>
         contact no.03313732935<br>

    </address>

   
</div>

